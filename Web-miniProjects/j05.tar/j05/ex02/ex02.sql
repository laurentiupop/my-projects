use db_flpop;
INSERT INTO `ft_table` (`id`, `login`, `groupe`, `date_de_creation`) VALUES
(NULL, 'loki', 'staff', '2013-05-01'),
(NULL, 'scadoux', 'student', '2014-01-01'),
(NULL, 'chap', 'staff', '2011-04-27'),
(NULL, 'bambou', 'staff', '2014-03-01'),
(NULL, 'fantomet', 'staff', '2010-04-03');
